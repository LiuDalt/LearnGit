package com.example.accessibility.sharepre;

public enum Type{
    INTEGER, BOOLEAN, STRING, STRING_SET, FLOAT, LONG
}
