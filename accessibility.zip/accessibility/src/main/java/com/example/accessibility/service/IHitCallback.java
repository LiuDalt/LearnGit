package com.example.accessibility.service;

public interface IHitCallback {
    void onHit(OperateState state);
}
