package com.example.accessibility.sharepre;

public class SharePreferenceConstant {
    public static final String LAST_START_OPERATE_TIME = "last_start_operate_time";
    public static final String GROUP_FULL_COUNT = "group_full_count";
    public static final String ONLY_MANAGER_SEND_MSG = "only_manager_send_msg";
    public static final String LAST_START = "last_start";
    public static final String LAST_END = "last_end";
    public static final String DEFAULT_INPUT_TEXT = "I saw a super hot and sexy mixed-race girl. Do you know her? I want her contact. https://bggray-mobile.like.video/s/6607378458340811630?c=whatsapp&special=1&l=en";
    public static final String INPUT_TEXT_INFO = "input_text_info";
    public static final String TEXT_SET = "text_set";
    public static final String OPREATE_COUNT = "operate_count";
}
