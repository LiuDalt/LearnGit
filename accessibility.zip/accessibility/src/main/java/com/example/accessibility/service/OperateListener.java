package com.example.accessibility.service;

public interface OperateListener {
    void onOperateStart();
    void onOperateEnd();
}
