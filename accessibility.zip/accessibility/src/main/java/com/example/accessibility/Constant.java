package com.example.accessibility;

public class Constant {
    public static final String[] mTexts = new String[]{
            "Great Prizes! There's 20 million dollars of activity on the LIKE APP and Taylor Swifit is also sending video wishes. Hurry to get money https://like.onelink.me/FvnB?pid=WhatsApp_video_sharing_test&c=6607378458340811630\n" +
                    "\n" +
                    "Great Prizes! There's 20 million dollars of activity on the LIKE APP and Taylor Swifit is also sending video wishes. Hurry to get money https://like.onelink.me/FvnB?pid=WhatsApp_video_sharing_test&c=6607378458340811630\n" +
                    "\n" +
                    "Great Prizes! There's 20 million dollars of activity on the LIKE APP and Taylor Swifit is also sending video wishes. Hurry to get money https://like.onelink.me/FvnB?pid=WhatsApp_video_sharing_test&c=6607378458340811630",
            "I find many very sexy girls in this app.  Only 1200INR and excellent massage with happy ending. Click here https://like.onelink.me/FvnB?pid=WhatsApp_video_sharing_test&c=6607378458340811630\n" +
                    "\n" +
                    "I find many very sexy girls in this app.  Only 1200INR and excellent massage with happy ending. Click herehttps://like.onelink.me/FvnB?pid=WhatsApp_video_sharing_test&c=6607378458340811630\n" +
                    "\n" +
                    "I find many very sexy girls in this app.  Only 1200INR and excellent massage with happy ending. Click here https://like.onelink.me/FvnB?pid=WhatsApp_video_sharing_test&c=6607378458340811630",
            "This Country is giving free citizenship only you have to do is to get intimate with 3 womens. Click on the link and know more about this https://like.onelink.me/FvnB?pid=WhatsApp_video_sharing_test&c=6607378458340811630\n" +
                    "\n" +
                    "This Country is giving free citizenship only you have to do is to get intimate with 3 womens. Click on the link and know more about this https://like.onelink.me/FvnB?pid=WhatsApp_video_sharing_test&c=6607378458340811630\n" +
                    "\n" +
                    "This Country is giving free citizenship only you have to do is to get intimate with 3 womens. Click on the link and know more about this https://like.onelink.me/FvnB?pid=WhatsApp_video_sharing_test&c=6607378458340811630"
    };
//    //测试文案
//    public static final String[] mTexts = new String[]{
//            "hi everybody, nice to meet you!"
//    };
}
