package com.example.accessibility.service;

public class WhatsAppConstant {
    public static final String WHATSAPP = "com.whatsapp";
    public static final String WHATSAPP_HOME_ACTIVITY = WHATSAPP + ".HomeActivity";
    public static final String RES_PREFIX = WHATSAPP + ":id/";
    public static final int NUM_PER_READ_DEFAULT = 1;
    public static final int OPERATE_TIME_DEFAULT = 16;//每天12点发
}
